import { useEffect, useState } from "react";
import api from "../api";

export default function Dashboard() {
  const [assignments, setAssignments] = useState([]);

  useEffect(() => {
    api.get("/assignments").then(r => setAssignments(r.data));
  }, []);

  const total = assignments.length;
  const assigned = assignments.filter(a => a.assegnato_a).length;
  const free = total - assigned;

  return (
    <div>
      <h1>Dashboard</h1>
      <p>PC totali: {total}</p>
      <p>PC assegnati: {assigned}</p>
      <p>PC liberi: {free}</p>
    </div>
  );
}