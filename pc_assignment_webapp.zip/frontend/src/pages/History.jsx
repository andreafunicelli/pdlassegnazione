import { useEffect, useState } from "react";
import api from "../api";

export default function History() {
  const [assignments, setAssignments] = useState([]);

  useEffect(() => {
    api.get("/assignments").then(r => setAssignments(r.data));
  }, []);

  return (
    <div>
      <h1>Storico Assegnazioni</h1>
      <table>
        <thead>
          <tr>
            <th>ID</th><th>Asset Tag</th><th>Utente</th><th>Data</th>
          </tr>
        </thead>
        <tbody>
          {assignments.map(a => (
            <tr key={a.id}>
              <td>{a.id}</td>
              <td>{a.asset_tag}</td>
              <td>{a.assegnato_a}</td>
              <td>{a.data_assegnazione}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}