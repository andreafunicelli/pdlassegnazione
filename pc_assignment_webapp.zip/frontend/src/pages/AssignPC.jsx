import { useEffect, useState } from "react";
import api from "../api";

export default function AssignPC() {
  const [naming, setNaming] = useState([]);
  const [checklist, setChecklist] = useState([]);
  const [software, setSoftware] = useState([]);
  const [form, setForm] = useState({ asset_tag: "", naming_id: null, checklist: {}, software: {}, assegnato_a: "" });

  useEffect(() => {
    api.get("/naming_conventions").then(r => setNaming(r.data));
    api.get("/checklist_items").then(r => setChecklist(r.data));
    api.get("/software_packages").then(r => setSoftware(r.data));
  }, []);

  const submit = () => {
    api.post("/assignments", {
      asset_tag: form.asset_tag,
      naming_id: form.naming_id,
      checklist_ok: Object.values(form.checklist).every(v => v),
      software_installed: Object.values(form.software).every(v => v),
      assegnato_a: form.assegnato_a
    }).then(() => alert("PC assegnato!"));
  };

  return (
    <div>
      <h1>Assegna un nuovo PC</h1>
      <input placeholder="Asset Tag" onChange={e=>setForm({...form,asset_tag:e.target.value})}/>
      <select onChange={e=>setForm({...form,naming_id:+e.target.value})}>
        <option>-- Naming --</option>
        {naming.map(n=> <option key={n.id} value={n.id}>{n.descrizione}</option>)}
      </select>
      <h2>Checklist</h2>
      {checklist.map(item=> (
        <label key={item.id}>
          <input type="checkbox"
            onChange={e=>setForm({
              ...form,
              checklist: { ...form.checklist, [item.id]: e.target.checked }
            })}
          /> {item.descrizione}
        </label>
      ))}
      <h2>Software</h2>
      {software.map(s=> (
        <label key={s.id}>
          <input type="checkbox"
            onChange={e=>setForm({
              ...form,
              software: { ...form.software, [s.id]: e.target.checked }
            })}
          /> {s.nome} {s.versione}
        </label>
      ))}
      <input placeholder="Assegnato a" onChange={e=>setForm({...form,assegnato_a:e.target.value})}/>
      <button onClick={submit}>Salva</button>
    </div>
  );
}