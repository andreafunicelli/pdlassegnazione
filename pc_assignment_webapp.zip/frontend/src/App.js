import { Routes, Route, Link } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import AssignPC from "./pages/AssignPC";
import History from "./pages/History";

export default function App() {
  return (
    <>
      <nav>
        <Link to="/">Dashboard</Link> |{" "}
        <Link to="/assign">Assegna PC</Link> |{" "}
        <Link to="/history">Storico</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/assign" element={<AssignPC />} />
        <Route path="/history" element={<History />} />
      </Routes>
    </>
  );
}