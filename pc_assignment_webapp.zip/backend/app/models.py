from . import db
from datetime import date

class NamingConvention(db.Model):
    __tablename__ = 'naming_conventions'
    id = db.Column(db.Integer, primary_key=True)
    prefisso = db.Column(db.String, nullable=False)
    descrizione = db.Column(db.String, nullable=False)

class ChecklistItem(db.Model):
    __tablename__ = 'checklist_items'
    id = db.Column(db.Integer, primary_key=True)
    descrizione = db.Column(db.String, nullable=False)
    obbligatorio = db.Column(db.Boolean, default=True)

class SoftwarePackage(db.Model):
    __tablename__ = 'software_packages'
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String, nullable=False)
    versione = db.Column(db.String)
    licenza = db.Column(db.String)
    categoria = db.Column(db.String)

class Assignment(db.Model):
    __tablename__ = 'assignments'
    id = db.Column(db.Integer, primary_key=True)
    asset_tag = db.Column(db.String, nullable=False)
    naming_id = db.Column(db.Integer, db.ForeignKey('naming_conventions.id'))
    checklist_ok = db.Column(db.Boolean, default=False)
    software_installed = db.Column(db.Boolean, default=False)
    assegnato_a = db.Column(db.String)
    data_assegnazione = db.Column(db.Date, default=date.today)