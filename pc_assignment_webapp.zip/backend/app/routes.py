from flask import Blueprint, jsonify, request
from .models import db, NamingConvention, ChecklistItem, SoftwarePackage, Assignment

bp = Blueprint('api', __name__)

# Naming
@bp.route("/naming_conventions", methods=["GET"])
def get_naming():
    items = NamingConvention.query.all()
    return jsonify([{"id": i.id, "prefisso": i.prefisso, "descrizione": i.descrizione} for i in items])

# Checklist
@bp.route("/checklist_items", methods=["GET"])
def get_checklist():
    items = ChecklistItem.query.all()
    return jsonify([{"id": i.id, "descrizione": i.descrizione, "obbligatorio": i.obbligatorio} for i in items])

# Software
@bp.route("/software_packages", methods=["GET"])
def get_software():
    items = SoftwarePackage.query.all()
    return jsonify([{"id": i.id, "nome": i.nome, "versione": i.versione, "licenza": i.licenza, "categoria": i.categoria} for i in items])

# Assignments
@bp.route("/assignments", methods=["GET"])
def list_assignments():
    assigns = Assignment.query.all()
    return jsonify([{
        "id": a.id, "asset_tag": a.asset_tag, "naming_id": a.naming_id,
        "checklist_ok": a.checklist_ok, "software_installed": a.software_installed,
        "assegnato_a": a.assegnato_a, "data_assegnazione": a.data_assegnazione.isoformat()
    } for a in assigns])

@bp.route("/assignments", methods=["POST"])
def create_assignment():
    data = request.json
    a = Assignment(
        asset_tag=data["asset_tag"],
        naming_id=data["naming_id"],
        checklist_ok=data.get("checklist_ok", False),
        software_installed=data.get("software_installed", False),
        assegnato_a=data.get("assegnato_a"),
    )
    db.session.add(a)
    db.session.commit()
    return jsonify({"id": a.id}), 201

@bp.route("/assignments/<int:id>", methods=["PUT"])
def update_assignment(id):
    a = Assignment.query.get_or_404(id)
    data = request.json
    for key in ["asset_tag","naming_id","checklist_ok","software_installed","assegnato_a"]:
        if key in data:
            setattr(a, key, data[key])
    db.session.commit()
    return jsonify({"status":"ok"})